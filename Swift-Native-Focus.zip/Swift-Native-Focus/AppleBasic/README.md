# Apple BASIC — Native iOS App

A fully native Applesoft BASIC interpreter for iOS, written in Swift with SwiftUI.

## Opening in Xcode

1. Download or clone this folder
2. Open `AppleBasic.xcodeproj` in Xcode (double-click)
3. Select your target device or simulator (requires iOS 17+)
4. Press **Cmd+R** to build and run

## Features

- Full Applesoft BASIC interpreter
- Retro Apple II phosphor terminal (green or amber)
- Animated cursor with scanline effect
- Toggle green/amber display with the circle button

## Supported BASIC Commands

### Program Control
| Command | Description |
|---------|-------------|
| `RUN` | Run the loaded program |
| `LIST` | List all program lines |
| `LIST 10-50` | List lines 10 through 50 |
| `NEW` | Erase the current program |
| `CLEAR` | Clear all variables |

### Statements
| Statement | Example |
|-----------|---------|
| `PRINT` | `PRINT "HELLO"` |
| `INPUT` | `INPUT "NAME? ";N$` |
| `LET` | `LET X = 42` |
| `IF/THEN` | `IF X > 10 THEN PRINT "BIG"` |
| `GOTO` | `GOTO 100` |
| `GOSUB` | `GOSUB 500` |
| `RETURN` | `RETURN` |
| `FOR/NEXT` | `FOR I=1 TO 10 : PRINT I : NEXT I` |
| `DIM` | `DIM A(10), B$(5)` |
| `DATA/READ` | `DATA 1,2,3 : READ X` |
| `RESTORE` | `RESTORE` |
| `ON/GOTO` | `ON X GOTO 100,200,300` |
| `ON/GOSUB` | `ON X GOSUB 100,200,300` |
| `DEF FN` | `DEF FN SQ(X) = X*X` |
| `REM` | `REM THIS IS A COMMENT` |
| `END` | `END` |
| `STOP` | `STOP` |
| `HOME` | Clear screen |
| `VTAB n` | Move cursor to row n |
| `HTAB n` | Move cursor to column n |

### Math Functions
`INT`, `ABS`, `SQR`, `SIN`, `COS`, `TAN`, `ATN`, `EXP`, `LOG`, `RND`, `SGN`

### String Functions
`LEFT$(s,n)`, `RIGHT$(s,n)`, `MID$(s,start,len)`, `LEN(s)`, `ASC(s)`, `CHR$(n)`, `STR$(n)`, `VAL(s)`

### Operators
`+`, `-`, `*`, `/`, `^`, `=`, `<>`, `<`, `>`, `<=`, `>=`, `AND`, `OR`, `NOT`

## Example Programs

### Hello World
```
10 PRINT "HELLO, WORLD!"
20 END
RUN
```

### Fibonacci
```
10 A = 0 : B = 1
20 FOR I = 1 TO 15
30 PRINT A
40 C = A + B : A = B : B = C
50 NEXT I
RUN
```

### Guessing Game
```
10 REM GUESSING GAME
20 N = INT(RND(1) * 100) + 1
30 PRINT "GUESS A NUMBER 1-100"
40 INPUT "YOUR GUESS: ";G
50 IF G < N THEN PRINT "TOO LOW" : GOTO 40
60 IF G > N THEN PRINT "TOO HIGH" : GOTO 40
70 PRINT "CORRECT!"
RUN
```

### Times Table
```
10 FOR I = 1 TO 10
20 FOR J = 1 TO 10
30 PRINT I*J,
40 NEXT J
50 PRINT
60 NEXT I
RUN
```

## Requirements
- iOS 17.0+
- Xcode 15.0+
- Swift 5.9+
