import Foundation

// MARK: - Token Types

enum TokenType: Equatable {
    case number(Double)
    case string(String)
    case identifier(String)
    case keyword(Keyword)
    case op(String)
    case comma
    case semicolon
    case colon
    case lparen
    case rparen
    case newline
    case eof
}

enum Keyword: String, CaseIterable {
    case PRINT, INPUT, LET, IF, THEN, ELSE
    case GOTO, GOSUB, RETURN, FOR, TO, STEP, NEXT
    case END, STOP, REM
    case RUN, LIST, NEW, CLEAR, LOAD, SAVE
    case DIM, DATA, READ, RESTORE
    case ON, AND, OR, NOT
    case INT, ABS, SQR, SIN, COS, TAN, ATN, EXP, LOG, RND, SGN
    case LEFT, RIGHT, MID, LEN, STR, VAL, CHR, ASC
    case PEEK, POKE, HOME, VTAB, HTAB, INVERSE, NORMAL, FLASH
    case TAB, SPC
    case FN, DEF
    case GET
}

struct Token {
    let type: TokenType
    let line: Int
}

// MARK: - Tokenizer

class Tokenizer {
    private let source: String
    private var pos: String.Index
    private var line: Int = 0

    init(source: String, line: Int = 0) {
        self.source = source
        self.pos = source.startIndex
        self.line = line
    }

    func tokenize() -> [Token] {
        var tokens: [Token] = []
        while pos < source.endIndex {
            skipSpaces()
            guard pos < source.endIndex else { break }
            let ch = source[pos]

            if ch == "\n" {
                tokens.append(Token(type: .newline, line: line))
                advance()
            } else if ch.isNumber || (ch == "." && peek()?.isNumber == true) {
                tokens.append(readNumber())
            } else if ch == "\"" {
                tokens.append(readString())
            } else if ch.isLetter {
                tokens.append(readIdentifierOrKeyword())
            } else if ch == "<" || ch == ">" || ch == "=" {
                tokens.append(readRelop())
            } else if "+-*/^".contains(ch) {
                tokens.append(Token(type: .op(String(ch)), line: line))
                advance()
            } else if ch == "," {
                tokens.append(Token(type: .comma, line: line))
                advance()
            } else if ch == ";" {
                tokens.append(Token(type: .semicolon, line: line))
                advance()
            } else if ch == ":" {
                tokens.append(Token(type: .colon, line: line))
                advance()
            } else if ch == "(" {
                tokens.append(Token(type: .lparen, line: line))
                advance()
            } else if ch == ")" {
                tokens.append(Token(type: .rparen, line: line))
                advance()
            } else {
                advance()
            }
        }
        tokens.append(Token(type: .eof, line: line))
        return tokens
    }

    private func skipSpaces() {
        while pos < source.endIndex && source[pos] == " " {
            advance()
        }
    }

    private func readNumber() -> Token {
        var s = ""
        var hasDot = false
        var hasE = false
        while pos < source.endIndex {
            let c = source[pos]
            if c.isNumber {
                s.append(c); advance()
            } else if c == "." && !hasDot && !hasE {
                hasDot = true; s.append(c); advance()
            } else if (c == "E" || c == "e") && !hasE {
                hasE = true; s.append(c); advance()
                if pos < source.endIndex && (source[pos] == "+" || source[pos] == "-") {
                    s.append(source[pos]); advance()
                }
            } else { break }
        }
        return Token(type: .number(Double(s) ?? 0), line: line)
    }

    private func readString() -> Token {
        advance()
        var s = ""
        while pos < source.endIndex && source[pos] != "\"" && source[pos] != "\n" {
            s.append(source[pos]); advance()
        }
        if pos < source.endIndex && source[pos] == "\"" { advance() }
        return Token(type: .string(s), line: line)
    }

    private func readIdentifierOrKeyword() -> Token {
        var s = ""
        while pos < source.endIndex && (source[pos].isLetter || source[pos].isNumber) {
            s.append(source[pos]); advance()
        }
        let upper = s.uppercased()

        if pos < source.endIndex && source[pos] == "$" {
            s.append("$"); advance()
            return Token(type: .identifier(s.uppercased()), line: line)
        }
        if pos < source.endIndex && source[pos] == "%" {
            s.append("%"); advance()
            return Token(type: .identifier(s.uppercased()), line: line)
        }

        if let kw = Keyword(rawValue: upper) {
            if kw == .LEFT || kw == .RIGHT || kw == .MID || kw == .STR || kw == .CHR {
                if pos < source.endIndex && source[pos] == "$" {
                    advance()
                }
            }
            return Token(type: .keyword(kw), line: line)
        }
        return Token(type: .identifier(upper), line: line)
    }

    private func readRelop() -> Token {
        let c = source[pos]; advance()
        if pos < source.endIndex {
            let n = source[pos]
            if c == "<" && n == ">" { advance(); return Token(type: .op("<>"), line: line) }
            if c == "<" && n == "=" { advance(); return Token(type: .op("<="), line: line) }
            if c == ">" && n == "=" { advance(); return Token(type: .op(">="), line: line) }
        }
        return Token(type: .op(String(c)), line: line)
    }

    @discardableResult
    private func advance() {
        pos = source.index(after: pos)
    }

    private func peek() -> Character? {
        let next = source.index(after: pos)
        return next < source.endIndex ? source[next] : nil
    }
}

// MARK: - BASIC Value

enum BASICValue {
    case number(Double)
    case string(String)

    var asDouble: Double {
        switch self {
        case .number(let n): return n
        case .string(let s): return Double(s) ?? 0
        }
    }
    var asInt: Int { return Int(asDouble) }
    var asString: String {
        switch self {
        case .number(let n):
            if n == n.rounded() && abs(n) < 1e15 {
                let i = Int(n)
                return " \(i)"
            }
            return " \(n)"
        case .string(let s): return s
        }
    }
    var isString: Bool {
        if case .string = self { return true }
        return false
    }
    var isTrue: Bool { asDouble != 0 }
}

// MARK: - Errors

enum BASICError: Error {
    case syntaxError(String)
    case undefinedVariable(String)
    case divisionByZero
    case typeMismatch
    case undefinedLine(Int)
    case nextWithoutFor
    case returnWithoutGosub
    case outOfMemory
    case illegalQuantity
    case overflow
    case stringTooLong
    case badSubscript
    case redimedArray
    case formulaToComplex
    case custom(String)
    case programEnd
    case stopped

    var message: String {
        switch self {
        case .syntaxError(let s): return "?SYNTAX ERROR\(s.isEmpty ? "" : " - \(s)")"
        case .undefinedVariable(let v): return "?UNDEFINED VARIABLE \(v)"
        case .divisionByZero: return "?DIVISION BY ZERO"
        case .typeMismatch: return "?TYPE MISMATCH"
        case .undefinedLine(let n): return "?UNDEFINED LINE \(n)"
        case .nextWithoutFor: return "?NEXT WITHOUT FOR"
        case .returnWithoutGosub: return "?RETURN WITHOUT GOSUB"
        case .outOfMemory: return "?OUT OF MEMORY"
        case .illegalQuantity: return "?ILLEGAL QUANTITY"
        case .overflow: return "?OVERFLOW"
        case .stringTooLong: return "?STRING TOO LONG"
        case .badSubscript: return "?BAD SUBSCRIPT"
        case .redimedArray: return "?REDIM'D ARRAY"
        case .formulaToComplex: return "?FORMULA TOO COMPLEX"
        case .custom(let s): return "?\(s)"
        case .programEnd: return ""
        case .stopped: return "BREAK"
        }
    }
}

// MARK: - Stack Frame

struct ForFrame {
    let variable: String
    let limit: Double
    let step: Double
    let returnLine: Int
    let returnStatementIndex: Int
}

struct GosubFrame {
    let returnLine: Int
    let returnStatementIndex: Int
}

enum StackFrame {
    case forLoop(ForFrame)
    case gosub(GosubFrame)
}

// MARK: - Interpreter

class BASICInterpreter {

    var outputHandler: ((String) -> Void)?
    var inputHandler: ((String, @escaping (String) -> Void) -> Void)?

    private var program: [Int: [String]] = [:]
    private var sortedLines: [Int] = []

    private var numVars: [String: Double] = [:]
    private var strVars: [String: String] = [:]
    private var numArrays: [String: ([Int], [Double])] = [:]
    private var strArrays: [String: ([Int], [String])] = [:]
    private var userFunctions: [String: (params: [String], expr: String)] = [:]

    private var dataList: [BASICValue] = []
    private var dataPointer: Int = 0

    private var callStack: [StackFrame] = []
    private var currentLine: Int = 0
    private var currentStatementIndex: Int = 0
    private var running: Bool = false
    private var stopped: Bool = false

    private var cursorColumn: Int = 0
    private var inverseMode: Bool = false

    var programLines: [Int: String] {
        var result: [Int: String] = [:]
        for (num, stmts) in program {
            result[num] = stmts.joined(separator: ":")
        }
        return result
    }

    // MARK: - Program Management

    func addLine(number: Int, text: String) {
        if text.trimmingCharacters(in: .whitespaces).isEmpty {
            program.removeValue(forKey: number)
        } else {
            let statements = splitStatements(text)
            program[number] = statements
        }
        sortedLines = program.keys.sorted()
    }

    func newProgram() {
        program = [:]
        sortedLines = []
        clearVariables()
        dataList = []
        dataPointer = 0
        callStack = []
        currentLine = 0
        running = false
    }

    func clearVariables() {
        numVars = [:]
        strVars = [:]
        numArrays = [:]
        strArrays = [:]
        userFunctions = [:]
        dataList = []
        dataPointer = 0
        callStack = []
    }

    func listProgram(from: Int? = nil, to: Int? = nil) -> String {
        var lines: [String] = []
        for lineNum in sortedLines {
            if let f = from, lineNum < f { continue }
            if let t = to, lineNum > t { continue }
            let stmts = program[lineNum]!.joined(separator: ":")
            lines.append("\(lineNum) \(stmts)")
        }
        return lines.joined(separator: "\n")
    }

    // MARK: - Run

    func run(startLine: Int? = nil, completion: @escaping () -> Void) {
        stopped = false
        running = true
        clearVariables()
        collectData()

        if let sl = startLine {
            guard let idx = sortedLines.firstIndex(of: sl) else {
                output("?UNDEFINED LINE \(sl)\n")
                running = false
                completion()
                return
            }
            currentLine = sl
            _ = idx
        } else {
            guard let first = sortedLines.first else {
                running = false
                completion()
                return
            }
            currentLine = first
        }
        currentStatementIndex = 0
        executeProgram(completion: completion)
    }

    func stop() {
        stopped = true
    }

    private func executeProgram(completion: @escaping () -> Void) {
        guard running && !stopped else {
            running = false
            if stopped { output("BREAK\n") }
            completion()
            return
        }

        guard let stmts = program[currentLine] else {
            running = false
            completion()
            return
        }

        guard currentStatementIndex < stmts.count else {
            advanceLine(completion: completion)
            return
        }

        let stmtText = stmts[currentStatementIndex]
        let savedLine = currentLine
        let savedIdx = currentStatementIndex

        do {
            let result = try executeStatement(stmtText)
            switch result {
            case .continue:
                if currentLine == savedLine && currentStatementIndex == savedIdx {
                    currentStatementIndex += 1
                    if currentStatementIndex >= (program[currentLine]?.count ?? 0) {
                        advanceLine(completion: completion)
                    } else {
                        executeProgram(completion: completion)
                    }
                } else {
                    currentStatementIndex = currentStatementIndex
                    executeProgram(completion: completion)
                }
            case .jump(let line):
                guard sortedLines.contains(line) else {
                    throw BASICError.undefinedLine(line)
                }
                currentLine = line
                currentStatementIndex = 0
                executeProgram(completion: completion)
            case .jumpStatement(let line, let si):
                currentLine = line
                currentStatementIndex = si
                executeProgram(completion: completion)
            case .end:
                running = false
                completion()
            case .inputNeeded(let prompt, let vars):
                handleInput(prompt: prompt, vars: vars, completion: completion)
            case .getNeeded(let varName):
                handleGet(varName: varName, completion: completion)
            }
        } catch BASICError.stopped {
            running = false
            output("BREAK IN \(currentLine)\n")
            completion()
        } catch BASICError.programEnd {
            running = false
            completion()
        } catch let err as BASICError {
            running = false
            output("\(err.message)\n")
            output("IN LINE \(currentLine)\n")
            completion()
        } catch {
            running = false
            output("?ERROR IN LINE \(currentLine)\n")
            completion()
        }
    }

    private func advanceLine(completion: @escaping () -> Void) {
        guard let idx = sortedLines.firstIndex(of: currentLine),
              idx + 1 < sortedLines.count else {
            running = false
            completion()
            return
        }
        currentLine = sortedLines[idx + 1]
        currentStatementIndex = 0
        executeProgram(completion: completion)
    }

    // MARK: - Input Handling

    private func handleInput(prompt: String, vars: [String], completion: @escaping () -> Void) {
        output(prompt)
        inputHandler?(prompt) { [weak self] userInput in
            guard let self = self else { return }
            self.output(userInput + "\n")
            let parts = userInput.components(separatedBy: ",")
            for (i, varName) in vars.enumerated() {
                let val = i < parts.count ? parts[i].trimmingCharacters(in: .whitespaces) : ""
                if varName.hasSuffix("$") {
                    self.strVars[varName] = val
                } else {
                    self.numVars[varName] = Double(val) ?? 0
                }
            }
            self.currentStatementIndex += 1
            if self.currentStatementIndex >= (self.program[self.currentLine]?.count ?? 0) {
                self.advanceLine(completion: completion)
            } else {
                self.executeProgram(completion: completion)
            }
        }
    }

    private func handleGet(varName: String, completion: @escaping () -> Void) {
        inputHandler?("") { [weak self] userInput in
            guard let self = self else { return }
            let ch = userInput.first.map { String($0) } ?? ""
            if varName.hasSuffix("$") {
                self.strVars[varName] = ch
            } else {
                self.numVars[varName] = Double(ch) ?? 0
            }
            self.currentStatementIndex += 1
            if self.currentStatementIndex >= (self.program[self.currentLine]?.count ?? 0) {
                self.advanceLine(completion: completion)
            } else {
                self.executeProgram(completion: completion)
            }
        }
    }

    // MARK: - Execute Statement

    enum ExecResult {
        case `continue`
        case jump(Int)
        case jumpStatement(Int, Int)
        case end
        case inputNeeded(String, [String])
        case getNeeded(String)
    }

    private func executeStatement(_ text: String) throws -> ExecResult {
        if stopped { throw BASICError.stopped }
        let trimmed = text.trimmingCharacters(in: .whitespaces)
        if trimmed.isEmpty { return .continue }

        let tokens = Tokenizer(source: trimmed, line: currentLine).tokenize()
        var pos = 0

        func peek() -> Token { pos < tokens.count ? tokens[pos] : Token(type: .eof, line: 0) }
        func consume() -> Token { let t = tokens[pos]; pos += 1; return t }
        func expectKeyword(_ kw: Keyword) throws { let t = consume(); guard case .keyword(let k) = t.type, k == kw else { throw BASICError.syntaxError("") } }

        guard pos < tokens.count else { return .continue }
        let first = tokens[pos]

        switch first.type {
        case .keyword(let kw):
            pos += 1
            switch kw {
            case .REM:
                return .continue

            case .PRINT:
                return try executePrint(tokens: tokens, pos: &pos)

            case .INPUT:
                return try executeInputStatement(tokens: tokens, pos: &pos)

            case .GET:
                guard case .identifier(let v) = peek().type else { throw BASICError.syntaxError("") }
                _ = consume()
                return .getNeeded(v)

            case .LET:
                return try executeLet(tokens: tokens, pos: &pos)

            case .IF:
                return try executeIf(tokens: tokens, pos: &pos)

            case .GOTO:
                let expr = try evalExpression(tokens: tokens, pos: &pos)
                let lineNum = Int(expr.asDouble)
                guard sortedLines.contains(lineNum) else { throw BASICError.undefinedLine(lineNum) }
                return .jump(lineNum)

            case .GOSUB:
                let expr = try evalExpression(tokens: tokens, pos: &pos)
                let lineNum = Int(expr.asDouble)
                guard sortedLines.contains(lineNum) else { throw BASICError.undefinedLine(lineNum) }
                let nextIdx = currentStatementIndex + 1
                let nextLine: Int
                if nextIdx < (program[currentLine]?.count ?? 0) {
                    nextLine = currentLine
                } else {
                    let idx = sortedLines.firstIndex(of: currentLine) ?? 0
                    nextLine = idx + 1 < sortedLines.count ? sortedLines[idx + 1] : -1
                }
                callStack.append(.gosub(GosubFrame(returnLine: nextLine, returnStatementIndex: nextIdx < (program[currentLine]?.count ?? 0) ? nextIdx : 0)))
                return .jump(lineNum)

            case .RETURN:
                while let frame = callStack.last {
                    callStack.removeLast()
                    if case .gosub(let gf) = frame {
                        if gf.returnLine == -1 { return .end }
                        return .jumpStatement(gf.returnLine, gf.returnStatementIndex)
                    }
                }
                throw BASICError.returnWithoutGosub

            case .FOR:
                return try executeFor(tokens: tokens, pos: &pos)

            case .NEXT:
                return try executeNext(tokens: tokens, pos: &pos)

            case .END, .STOP:
                if kw == .STOP { output("BREAK IN \(currentLine)\n") }
                throw BASICError.programEnd

            case .DIM:
                try executeDim(tokens: tokens, pos: &pos)
                return .continue

            case .DATA:
                return .continue

            case .READ:
                try executeRead(tokens: tokens, pos: &pos)
                return .continue

            case .RESTORE:
                dataPointer = 0
                return .continue

            case .ON:
                return try executeOn(tokens: tokens, pos: &pos)

            case .DEF:
                try executeDef(tokens: tokens, pos: &pos)
                return .continue

            case .HOME:
                output("\u{1B}[2J\u{1B}[H")
                return .continue

            case .VTAB:
                let v = try evalExpression(tokens: tokens, pos: &pos)
                output("\u{1B}[\(Int(v.asDouble));1H")
                return .continue

            case .HTAB:
                let h = try evalExpression(tokens: tokens, pos: &pos)
                output("\u{1B}[\(Int(h.asDouble))G")
                return .continue

            case .INVERSE:
                inverseMode = true
                return .continue

            case .NORMAL, .FLASH:
                inverseMode = false
                return .continue

            case .POKE:
                _ = try evalExpression(tokens: tokens, pos: &pos)
                if case .comma = peek().type { _ = consume() }
                _ = try evalExpression(tokens: tokens, pos: &pos)
                return .continue

            default:
                throw BASICError.syntaxError("")
            }

        case .identifier(let name):
            return try executeLet(tokens: tokens, pos: &pos)

        default:
            throw BASICError.syntaxError("")
        }
    }

    // MARK: - PRINT

    private func executePrint(tokens: [Token], pos: inout Int) throws -> ExecResult {
        var result = ""
        var suppressNewline = false

        while pos < tokens.count - 1 {
            let t = tokens[pos]
            switch t.type {
            case .semicolon:
                pos += 1
                suppressNewline = true
                continue
            case .comma:
                pos += 1
                let col = cursorColumn
                let tabStop = ((col / 14) + 1) * 14
                result += String(repeating: " ", count: tabStop - col)
                cursorColumn = tabStop
                suppressNewline = true
                continue
            case .keyword(let kw) where kw == .TAB || kw == .SPC:
                pos += 1
                if case .lparen = tokens[pos].type { pos += 1 }
                let n = try evalExpression(tokens: tokens, pos: &pos)
                if case .rparen = tokens[pos].type { pos += 1 }
                if kw == .TAB {
                    let target = max(Int(n.asDouble) - 1, 0)
                    if target > cursorColumn {
                        result += String(repeating: " ", count: target - cursorColumn)
                        cursorColumn = target
                    }
                } else {
                    let spaces = max(Int(n.asDouble), 0)
                    result += String(repeating: " ", count: spaces)
                    cursorColumn += spaces
                }
                suppressNewline = true
                continue
            default:
                break
            }

            let val = try evalExpression(tokens: tokens, pos: &pos)
            let s = val.isString ? val.asString : formatNumber(val.asDouble)
            result += s
            cursorColumn += s.count
            suppressNewline = false
        }

        if !suppressNewline {
            result += "\n"
            cursorColumn = 0
        }
        output(result)
        return .continue
    }

    private func formatNumber(_ n: Double) -> String {
        if n.isNaN { return " NAN" }
        if n.isInfinite { return n > 0 ? " INF" : "-INF" }
        if n == 0 { return " 0" }
        let absN = abs(n)
        if absN >= 0.01 && absN < 1e9 {
            if n == n.rounded() && absN < 1e15 {
                return " \(Int(n))"
            }
            let s = String(format: "%g", n)
            return n >= 0 ? " \(s)" : s
        }
        let s = String(format: "%E", n)
            .replacingOccurrences(of: "E+0", with: "E+")
            .replacingOccurrences(of: "E-0", with: "E-")
            .replacingOccurrences(of: "E+", with: "E")
        return n >= 0 ? " \(s)" : s
    }

    // MARK: - INPUT

    private func executeInputStatement(tokens: [Token], pos: inout Int) throws -> ExecResult {
        var prompt = "? "
        var vars: [String] = []

        if case .string(let s) = tokens[pos].type {
            prompt = s
            pos += 1
            if case .semicolon = tokens[pos].type { pos += 1 }
            else if case .comma = tokens[pos].type { pos += 1 }
        }

        while pos < tokens.count - 1 {
            if case .identifier(let v) = tokens[pos].type {
                vars.append(v)
                pos += 1
            } else if case .comma = tokens[pos].type {
                pos += 1
            } else { break }
        }

        return .inputNeeded(prompt, vars)
    }

    // MARK: - LET

    private func executeLet(tokens: [Token], pos: inout Int) throws -> ExecResult {
        guard case .identifier(let name) = tokens[pos].type else {
            throw BASICError.syntaxError("")
        }
        pos += 1

        var subscripts: [Int] = []
        if case .lparen = tokens[pos].type {
            pos += 1
            while true {
                let sub = try evalExpression(tokens: tokens, pos: &pos)
                subscripts.append(Int(sub.asDouble))
                if case .comma = tokens[pos].type { pos += 1 }
                else if case .rparen = tokens[pos].type { pos += 1; break }
                else { break }
            }
        }

        guard case .op("=") = tokens[pos].type else { throw BASICError.syntaxError("") }
        pos += 1

        let val = try evalExpression(tokens: tokens, pos: &pos)

        if subscripts.isEmpty {
            if name.hasSuffix("$") {
                guard val.isString else { throw BASICError.typeMismatch }
                strVars[name] = val.asString
            } else {
                strVars[name] = nil
                numVars[name] = val.asDouble
            }
        } else {
            try setArrayValue(name: name, subscripts: subscripts, value: val)
        }

        return .continue
    }

    // MARK: - IF

    private func executeIf(tokens: [Token], pos: inout Int) throws -> ExecResult {
        let cond = try evalExpression(tokens: tokens, pos: &pos)

        var expectingElse = false
        if case .keyword(let kw) = tokens[pos].type, kw == .THEN {
            pos += 1
        } else if case .keyword(let kw) = tokens[pos].type, kw == .GOTO {
        } else {
            throw BASICError.syntaxError("MISSING THEN")
        }

        if cond.isTrue {
            if case .number(let n) = tokens[pos].type {
                let lineNum = Int(n)
                guard sortedLines.contains(lineNum) else { throw BASICError.undefinedLine(lineNum) }
                return .jump(lineNum)
            }
            let remaining = tokens[pos...].map { tokenToString($0) }.joined(separator: " ")
            let subResult = try executeStatement(remaining.trimmingCharacters(in: .whitespaces))
            return subResult
        } else {
            while pos < tokens.count - 1 {
                if case .keyword(let kw) = tokens[pos].type, kw == .ELSE {
                    pos += 1
                    expectingElse = false
                    let remaining = tokens[pos...].map { tokenToString($0) }.joined(separator: " ")
                    return try executeStatement(remaining.trimmingCharacters(in: .whitespaces))
                }
                pos += 1
            }
        }
        return .continue
    }

    // MARK: - FOR / NEXT

    private func executeFor(tokens: [Token], pos: inout Int) throws -> ExecResult {
        guard case .identifier(let varName) = tokens[pos].type else { throw BASICError.syntaxError("") }
        pos += 1
        guard case .op("=") = tokens[pos].type else { throw BASICError.syntaxError("") }
        pos += 1
        let start = try evalExpression(tokens: tokens, pos: &pos)
        guard case .keyword(let tk) = tokens[pos].type, tk == .TO else { throw BASICError.syntaxError("") }
        pos += 1
        let limit = try evalExpression(tokens: tokens, pos: &pos)
        var step = 1.0
        if case .keyword(let sk) = tokens[pos].type, sk == .STEP {
            pos += 1
            let sv = try evalExpression(tokens: tokens, pos: &pos)
            step = sv.asDouble
        }

        callStack.removeAll { if case .forLoop(let f) = $0, f.variable == varName { return true }; return false }

        numVars[varName] = start.asDouble

        let nextLineIdx = (sortedLines.firstIndex(of: currentLine) ?? 0) + 1
        let nextLine = nextLineIdx < sortedLines.count ? sortedLines[nextLineIdx] : -1
        let nextSI = currentStatementIndex + 1 < (program[currentLine]?.count ?? 0) ? currentStatementIndex + 1 : 0

        let frame = ForFrame(
            variable: varName,
            limit: limit.asDouble,
            step: step,
            returnLine: nextSI > 0 ? currentLine : nextLine,
            returnStatementIndex: nextSI
        )
        callStack.append(.forLoop(frame))
        return .continue
    }

    private func executeNext(tokens: [Token], pos: inout Int) throws -> ExecResult {
        var varName: String? = nil
        if case .identifier(let v) = tokens[pos].type {
            varName = v; pos += 1
        }

        var frameIdx: Int? = nil
        for i in stride(from: callStack.count - 1, through: 0, by: -1) {
            if case .forLoop(let f) = callStack[i] {
                if varName == nil || f.variable == varName {
                    frameIdx = i
                    break
                }
            }
        }

        guard let fi = frameIdx, case .forLoop(let frame) = callStack[fi] else {
            throw BASICError.nextWithoutFor
        }

        let current = (numVars[frame.variable] ?? 0) + frame.step
        numVars[frame.variable] = current

        let done = frame.step >= 0 ? current > frame.limit : current < frame.limit
        if done {
            callStack.remove(at: fi)
            return .continue
        } else {
            return .jumpStatement(frame.returnLine, frame.returnStatementIndex)
        }
    }

    // MARK: - DIM

    private func executeDim(tokens: [Token], pos: inout Int) throws {
        while pos < tokens.count - 1 {
            guard case .identifier(let name) = tokens[pos].type else { break }
            pos += 1
            guard case .lparen = tokens[pos].type else { throw BASICError.syntaxError("") }
            pos += 1
            var dims: [Int] = []
            while true {
                let d = try evalExpression(tokens: tokens, pos: &pos)
                dims.append(Int(d.asDouble) + 1)
                if case .comma = tokens[pos].type { pos += 1 }
                else if case .rparen = tokens[pos].type { pos += 1; break }
                else { break }
            }
            let total = dims.reduce(1, *)
            if name.hasSuffix("$") {
                if strArrays[name] != nil { throw BASICError.redimedArray }
                strArrays[name] = (dims, [String](repeating: "", count: total))
            } else {
                if numArrays[name] != nil { throw BASICError.redimedArray }
                numArrays[name] = (dims, [Double](repeating: 0, count: total))
            }
            if case .comma = tokens[pos].type { pos += 1 }
        }
    }

    // MARK: - READ / DATA

    private func collectData() {
        dataList = []
        for lineNum in sortedLines {
            guard let stmts = program[lineNum] else { continue }
            for stmt in stmts {
                let t = stmt.trimmingCharacters(in: .whitespaces)
                if t.uppercased().hasPrefix("DATA") {
                    let rest = String(t.dropFirst(4)).trimmingCharacters(in: .whitespaces)
                    let items = rest.components(separatedBy: ",")
                    for item in items {
                        let s = item.trimmingCharacters(in: .whitespaces)
                        if let n = Double(s) {
                            dataList.append(.number(n))
                        } else {
                            let clean = s.trimmingCharacters(in: CharacterSet(charactersIn: "\""))
                            dataList.append(.string(clean))
                        }
                    }
                }
            }
        }
    }

    private func executeRead(tokens: [Token], pos: inout Int) throws {
        while pos < tokens.count - 1 {
            guard case .identifier(let name) = tokens[pos].type else { break }
            pos += 1
            guard dataPointer < dataList.count else { throw BASICError.custom("OUT OF DATA") }
            let val = dataList[dataPointer]
            dataPointer += 1
            if name.hasSuffix("$") {
                strVars[name] = val.asString
            } else {
                numVars[name] = val.asDouble
            }
            if case .comma = tokens[pos].type { pos += 1 }
        }
    }

    // MARK: - ON

    private func executeOn(tokens: [Token], pos: inout Int) throws -> ExecResult {
        let val = try evalExpression(tokens: tokens, pos: &pos)
        let idx = Int(val.asDouble)
        var isGosub = false
        if case .keyword(let kw) = tokens[pos].type {
            isGosub = (kw == .GOSUB)
            pos += 1
        }
        var lines: [Int] = []
        while pos < tokens.count - 1 {
            if case .number(let n) = tokens[pos].type {
                lines.append(Int(n)); pos += 1
            } else if case .comma = tokens[pos].type {
                pos += 1
            } else { break }
        }
        guard idx >= 1 && idx <= lines.count else { return .continue }
        let target = lines[idx - 1]
        guard sortedLines.contains(target) else { throw BASICError.undefinedLine(target) }
        if isGosub {
            let nextIdx = currentStatementIndex + 1
            let nextLine: Int
            if nextIdx < (program[currentLine]?.count ?? 0) {
                nextLine = currentLine
            } else {
                let i = sortedLines.firstIndex(of: currentLine) ?? 0
                nextLine = i + 1 < sortedLines.count ? sortedLines[i + 1] : -1
            }
            callStack.append(.gosub(GosubFrame(returnLine: nextLine, returnStatementIndex: nextIdx < (program[currentLine]?.count ?? 0) ? nextIdx : 0)))
        }
        return .jump(target)
    }

    // MARK: - DEF FN

    private func executeDef(tokens: [Token], pos: inout Int) throws {
        guard case .keyword(let fn) = tokens[pos].type, fn == .FN else { throw BASICError.syntaxError("") }
        pos += 1
        guard case .identifier(let name) = tokens[pos].type else { throw BASICError.syntaxError("") }
        pos += 1
        var params: [String] = []
        if case .lparen = tokens[pos].type {
            pos += 1
            while true {
                if case .identifier(let p) = tokens[pos].type { params.append(p); pos += 1 }
                if case .comma = tokens[pos].type { pos += 1 }
                else if case .rparen = tokens[pos].type { pos += 1; break }
                else { break }
            }
        }
        guard case .op("=") = tokens[pos].type else { throw BASICError.syntaxError("") }
        pos += 1
        let exprTokens = tokens[pos..<(tokens.count-1)].map { tokenToString($0) }.joined(separator: " ")
        userFunctions["FN\(name)"] = (params: params, expr: exprTokens)
    }

    // MARK: - Array Access

    private func getArrayValue(name: String, subscripts: [Int]) throws -> BASICValue {
        if name.hasSuffix("$") {
            if strArrays[name] == nil {
                strArrays[name] = ([11], [String](repeating: "", count: 11))
            }
            guard let (dims, data) = strArrays[name] else { throw BASICError.badSubscript }
            let idx = try arrayIndex(dims: dims, subscripts: subscripts)
            return .string(data[idx])
        } else {
            if numArrays[name] == nil {
                numArrays[name] = ([11], [Double](repeating: 0, count: 11))
            }
            guard let (dims, data) = numArrays[name] else { throw BASICError.badSubscript }
            let idx = try arrayIndex(dims: dims, subscripts: subscripts)
            return .number(data[idx])
        }
    }

    private func setArrayValue(name: String, subscripts: [Int], value: BASICValue) throws {
        if name.hasSuffix("$") {
            if strArrays[name] == nil {
                strArrays[name] = ([11], [String](repeating: "", count: 11))
            }
            guard var (dims, data) = strArrays[name] else { throw BASICError.badSubscript }
            let idx = try arrayIndex(dims: dims, subscripts: subscripts)
            data[idx] = value.asString
            strArrays[name] = (dims, data)
        } else {
            if numArrays[name] == nil {
                numArrays[name] = ([11], [Double](repeating: 0, count: 11))
            }
            guard var (dims, data) = numArrays[name] else { throw BASICError.badSubscript }
            let idx = try arrayIndex(dims: dims, subscripts: subscripts)
            data[idx] = value.asDouble
            numArrays[name] = (dims, data)
        }
    }

    private func arrayIndex(dims: [Int], subscripts: [Int]) throws -> Int {
        guard subscripts.count == dims.count else { throw BASICError.badSubscript }
        var idx = 0
        var multiplier = 1
        for i in stride(from: dims.count - 1, through: 0, by: -1) {
            guard subscripts[i] >= 0 && subscripts[i] < dims[i] else { throw BASICError.badSubscript }
            idx += subscripts[i] * multiplier
            multiplier *= dims[i]
        }
        return idx
    }

    // MARK: - Expression Evaluator

    func evalExpression(tokens: [Token], pos: inout Int) throws -> BASICValue {
        return try evalOr(tokens: tokens, pos: &pos)
    }

    private func evalOr(tokens: [Token], pos: inout Int) throws -> BASICValue {
        var left = try evalAnd(tokens: tokens, pos: &pos)
        while case .keyword(let kw) = tokens[pos].type, kw == .OR {
            pos += 1
            let right = try evalAnd(tokens: tokens, pos: &pos)
            left = BASICValue.number((left.isTrue || right.isTrue) ? -1 : 0)
        }
        return left
    }

    private func evalAnd(tokens: [Token], pos: inout Int) throws -> BASICValue {
        var left = try evalNot(tokens: tokens, pos: &pos)
        while case .keyword(let kw) = tokens[pos].type, kw == .AND {
            pos += 1
            let right = try evalNot(tokens: tokens, pos: &pos)
            left = BASICValue.number((left.isTrue && right.isTrue) ? -1 : 0)
        }
        return left
    }

    private func evalNot(tokens: [Token], pos: inout Int) throws -> BASICValue {
        if case .keyword(let kw) = tokens[pos].type, kw == .NOT {
            pos += 1
            let val = try evalNot(tokens: tokens, pos: &pos)
            return .number(val.isTrue ? 0 : -1)
        }
        return try evalComparison(tokens: tokens, pos: &pos)
    }

    private func evalComparison(tokens: [Token], pos: inout Int) throws -> BASICValue {
        let left = try evalAddSub(tokens: tokens, pos: &pos)
        guard case .op(let op) = tokens[pos].type,
              ["=", "<>", "<", ">", "<=", ">="].contains(op) else { return left }
        pos += 1
        let right = try evalAddSub(tokens: tokens, pos: &pos)

        if left.isString && right.isString {
            let ls = left.asString, rs = right.asString
            let res: Bool
            switch op {
            case "=": res = ls == rs
            case "<>": res = ls != rs
            case "<": res = ls < rs
            case ">": res = ls > rs
            case "<=": res = ls <= rs
            case ">=": res = ls >= rs
            default: res = false
            }
            return .number(res ? -1 : 0)
        } else {
            let ln = left.asDouble, rn = right.asDouble
            let res: Bool
            switch op {
            case "=": res = ln == rn
            case "<>": res = ln != rn
            case "<": res = ln < rn
            case ">": res = ln > rn
            case "<=": res = ln <= rn
            case ">=": res = ln >= rn
            default: res = false
            }
            return .number(res ? -1 : 0)
        }
    }

    private func evalAddSub(tokens: [Token], pos: inout Int) throws -> BASICValue {
        var left = try evalMulDiv(tokens: tokens, pos: &pos)
        while true {
            if case .op(let op) = tokens[pos].type, op == "+" || op == "-" {
                pos += 1
                let right = try evalMulDiv(tokens: tokens, pos: &pos)
                if op == "+" && left.isString && right.isString {
                    left = .string(left.asString + right.asString)
                } else if op == "+" {
                    left = .number(left.asDouble + right.asDouble)
                } else {
                    left = .number(left.asDouble - right.asDouble)
                }
            } else { break }
        }
        return left
    }

    private func evalMulDiv(tokens: [Token], pos: inout Int) throws -> BASICValue {
        var left = try evalPower(tokens: tokens, pos: &pos)
        while true {
            if case .op(let op) = tokens[pos].type, op == "*" || op == "/" {
                pos += 1
                let right = try evalPower(tokens: tokens, pos: &pos)
                if op == "*" {
                    left = .number(left.asDouble * right.asDouble)
                } else {
                    if right.asDouble == 0 { throw BASICError.divisionByZero }
                    left = .number(left.asDouble / right.asDouble)
                }
            } else { break }
        }
        return left
    }

    private func evalPower(tokens: [Token], pos: inout Int) throws -> BASICValue {
        var base = try evalUnary(tokens: tokens, pos: &pos)
        if case .op(let op) = tokens[pos].type, op == "^" {
            pos += 1
            let exp = try evalPower(tokens: tokens, pos: &pos)
            base = .number(pow(base.asDouble, exp.asDouble))
        }
        return base
    }

    private func evalUnary(tokens: [Token], pos: inout Int) throws -> BASICValue {
        if case .op(let op) = tokens[pos].type, op == "-" {
            pos += 1
            let val = try evalUnary(tokens: tokens, pos: &pos)
            return .number(-val.asDouble)
        }
        if case .op(let op) = tokens[pos].type, op == "+" {
            pos += 1
            return try evalUnary(tokens: tokens, pos: &pos)
        }
        return try evalPrimary(tokens: tokens, pos: &pos)
    }

    private func evalPrimary(tokens: [Token], pos: inout Int) throws -> BASICValue {
        let t = tokens[pos]
        switch t.type {
        case .number(let n):
            pos += 1
            return .number(n)
        case .string(let s):
            pos += 1
            return .string(s)
        case .lparen:
            pos += 1
            let val = try evalExpression(tokens: tokens, pos: &pos)
            if case .rparen = tokens[pos].type { pos += 1 }
            return val
        case .keyword(let kw):
            return try evalFunction(kw: kw, tokens: tokens, pos: &pos)
        case .identifier(let name):
            pos += 1
            if case .lparen = tokens[pos].type {
                pos += 1
                var subscripts: [Int] = []
                while true {
                    let sub = try evalExpression(tokens: tokens, pos: &pos)
                    subscripts.append(Int(sub.asDouble))
                    if case .comma = tokens[pos].type { pos += 1 }
                    else if case .rparen = tokens[pos].type { pos += 1; break }
                    else { break }
                }
                return try getArrayValue(name: name, subscripts: subscripts)
            }
            if name.hasSuffix("$") {
                return .string(strVars[name] ?? "")
            }
            return .number(numVars[name] ?? 0)
        default:
            return .number(0)
        }
    }

    private func evalFunction(kw: Keyword, tokens: [Token], pos: inout Int) throws -> BASICValue {
        pos += 1
        switch kw {
        case .INT:
            let v = try evalParenExpr(tokens: tokens, pos: &pos)
            return .number(floor(v.asDouble))
        case .ABS:
            let v = try evalParenExpr(tokens: tokens, pos: &pos)
            return .number(abs(v.asDouble))
        case .SQR:
            let v = try evalParenExpr(tokens: tokens, pos: &pos)
            guard v.asDouble >= 0 else { throw BASICError.illegalQuantity }
            return .number(sqrt(v.asDouble))
        case .SIN:
            let v = try evalParenExpr(tokens: tokens, pos: &pos)
            return .number(sin(v.asDouble))
        case .COS:
            let v = try evalParenExpr(tokens: tokens, pos: &pos)
            return .number(cos(v.asDouble))
        case .TAN:
            let v = try evalParenExpr(tokens: tokens, pos: &pos)
            return .number(tan(v.asDouble))
        case .ATN:
            let v = try evalParenExpr(tokens: tokens, pos: &pos)
            return .number(atan(v.asDouble))
        case .EXP:
            let v = try evalParenExpr(tokens: tokens, pos: &pos)
            return .number(exp(v.asDouble))
        case .LOG:
            let v = try evalParenExpr(tokens: tokens, pos: &pos)
            guard v.asDouble > 0 else { throw BASICError.illegalQuantity }
            return .number(log(v.asDouble))
        case .RND:
            let v = try evalParenExpr(tokens: tokens, pos: &pos)
            if v.asDouble < 0 { srand48(Int(v.asDouble)) }
            return .number(v.asDouble == 0 ? lastRnd : drand48())
        case .SGN:
            let v = try evalParenExpr(tokens: tokens, pos: &pos)
            let n = v.asDouble
            return .number(n > 0 ? 1 : (n < 0 ? -1 : 0))
        case .PEEK:
            let _ = try evalParenExpr(tokens: tokens, pos: &pos)
            return .number(0)
        case .LEN:
            let v = try evalParenExpr(tokens: tokens, pos: &pos)
            return .number(Double(v.asString.count))
        case .ASC:
            let v = try evalParenExpr(tokens: tokens, pos: &pos)
            guard let first = v.asString.unicodeScalars.first else { throw BASICError.illegalQuantity }
            return .number(Double(first.value))
        case .CHR:
            let v = try evalParenExpr(tokens: tokens, pos: &pos)
            let code = Int(v.asDouble)
            guard let scalar = Unicode.Scalar(code) else { throw BASICError.illegalQuantity }
            return .string(String(scalar))
        case .STR:
            let v = try evalParenExpr(tokens: tokens, pos: &pos)
            return .string(formatNumber(v.asDouble).trimmingCharacters(in: .whitespaces))
        case .VAL:
            let v = try evalParenExpr(tokens: tokens, pos: &pos)
            return .number(Double(v.asString.trimmingCharacters(in: .whitespaces)) ?? 0)
        case .LEFT:
            if case .lparen = tokens[pos].type { pos += 1 }
            let str = try evalExpression(tokens: tokens, pos: &pos)
            if case .comma = tokens[pos].type { pos += 1 }
            let n = try evalExpression(tokens: tokens, pos: &pos)
            if case .rparen = tokens[pos].type { pos += 1 }
            let count = max(0, Int(n.asDouble))
            return .string(String(str.asString.prefix(count)))
        case .RIGHT:
            if case .lparen = tokens[pos].type { pos += 1 }
            let str = try evalExpression(tokens: tokens, pos: &pos)
            if case .comma = tokens[pos].type { pos += 1 }
            let n = try evalExpression(tokens: tokens, pos: &pos)
            if case .rparen = tokens[pos].type { pos += 1 }
            let count = max(0, Int(n.asDouble))
            return .string(String(str.asString.suffix(count)))
        case .MID:
            if case .lparen = tokens[pos].type { pos += 1 }
            let str = try evalExpression(tokens: tokens, pos: &pos)
            if case .comma = tokens[pos].type { pos += 1 }
            let start = try evalExpression(tokens: tokens, pos: &pos)
            var length: Int? = nil
            if case .comma = tokens[pos].type {
                pos += 1
                let l = try evalExpression(tokens: tokens, pos: &pos)
                length = Int(l.asDouble)
            }
            if case .rparen = tokens[pos].type { pos += 1 }
            let s = str.asString
            let startIdx = max(0, Int(start.asDouble) - 1)
            guard startIdx <= s.count else { return .string("") }
            let fromIndex = s.index(s.startIndex, offsetBy: startIdx)
            if let len = length {
                let endIdx = s.index(fromIndex, offsetBy: min(len, s.distance(from: fromIndex, to: s.endIndex)))
                return .string(String(s[fromIndex..<endIdx]))
            }
            return .string(String(s[fromIndex...]))
        case .FN:
            guard case .identifier(let fname) = tokens[pos].type else { throw BASICError.syntaxError("") }
            pos += 1
            let argVal = try evalParenExpr(tokens: tokens, pos: &pos)
            guard let fn = userFunctions["FN\(fname)"] else { throw BASICError.custom("UNDEFINED FUNCTION") }
            let savedVars = numVars
            if let param = fn.params.first { numVars[param] = argVal.asDouble }
            let fnTokens = Tokenizer(source: fn.expr).tokenize()
            var fnPos = 0
            let result = try evalExpression(tokens: fnTokens, pos: &fnPos)
            numVars = savedVars
            return result
        default:
            return .number(0)
        }
    }

    private var lastRnd: Double = 0

    private func evalParenExpr(tokens: [Token], pos: inout Int) throws -> BASICValue {
        if case .lparen = tokens[pos].type { pos += 1 }
        let val = try evalExpression(tokens: tokens, pos: &pos)
        if case .rparen = tokens[pos].type { pos += 1 }
        return val
    }

    // MARK: - Helpers

    private func splitStatements(_ text: String) -> [String] {
        var statements: [String] = []
        var current = ""
        var inString = false
        var i = text.startIndex
        while i < text.endIndex {
            let c = text[i]
            if c == "\"" { inString = !inString }
            if !inString && c == ":" {
                let trimmed = current.trimmingCharacters(in: .whitespaces)
                if !trimmed.isEmpty { statements.append(trimmed) }
                current = ""
            } else {
                current.append(c)
            }
            i = text.index(after: i)
        }
        let trimmed = current.trimmingCharacters(in: .whitespaces)
        if !trimmed.isEmpty { statements.append(trimmed) }
        return statements
    }

    private func tokenToString(_ token: Token) -> String {
        switch token.type {
        case .number(let n): return String(n)
        case .string(let s): return "\"\(s)\""
        case .identifier(let i): return i
        case .keyword(let k): return k.rawValue
        case .op(let o): return o
        case .comma: return ","
        case .semicolon: return ";"
        case .colon: return ":"
        case .lparen: return "("
        case .rparen: return ")"
        case .newline: return "\n"
        case .eof: return ""
        }
    }

    private func output(_ text: String) {
        outputHandler?(text)
    }

    // MARK: - Direct Command Execution

    func executeDirectCommand(_ input: String, completion: @escaping (String) -> Void) {
        let trimmed = input.trimmingCharacters(in: .whitespaces)
        if trimmed.isEmpty { completion(""); return }

        let upper = trimmed.uppercased()

        if upper == "NEW" {
            newProgram()
            completion("")
            return
        }
        if upper == "CLEAR" {
            clearVariables()
            completion("")
            return
        }
        if upper == "RUN" {
            run { completion("") }
            return
        }
        if upper.hasPrefix("RUN ") {
            if let n = Int(upper.dropFirst(4).trimmingCharacters(in: .whitespaces)) {
                run(startLine: n) { completion("") }
            } else {
                completion("?SYNTAX ERROR\n")
            }
            return
        }
        if upper == "LIST" {
            let listing = listProgram()
            completion(listing.isEmpty ? "" : listing + "\n")
            return
        }
        if upper.hasPrefix("LIST ") {
            let rest = String(upper.dropFirst(5))
            let parts = rest.components(separatedBy: "-")
            let from = parts.count > 0 ? Int(parts[0].trimmingCharacters(in: .whitespaces)) : nil
            let to = parts.count > 1 ? Int(parts[1].trimmingCharacters(in: .whitespaces)) : from
            let listing = listProgram(from: from, to: to)
            completion(listing.isEmpty ? "" : listing + "\n")
            return
        }
        if upper == "CONT" {
            completion("?CAN'T CONTINUE\n")
            return
        }

        if let firstChar = trimmed.first, firstChar.isNumber {
            let parts = trimmed.split(separator: " ", maxSplits: 1)
            if let lineNum = Int(parts[0]) {
                let code = parts.count > 1 ? String(parts[1]) : ""
                addLine(number: lineNum, text: code)
                completion("")
                return
            }
        }

        var output = ""
        outputHandler = { output += $0 }
        running = true
        let stmts = splitStatements(trimmed)
        var stmtIdx = 0

        func execNext() {
            guard stmtIdx < stmts.count else {
                running = false
                completion(output)
                return
            }
            let stmt = stmts[stmtIdx]
            stmtIdx += 1
            do {
                let result = try executeStatement(stmt)
                switch result {
                case .continue:
                    execNext()
                case .inputNeeded(let prompt, let vars):
                    inputHandler?(prompt) { [self] userInput in
                        output += userInput + "\n"
                        let parts2 = userInput.components(separatedBy: ",")
                        for (i, v) in vars.enumerated() {
                            let val = i < parts2.count ? parts2[i].trimmingCharacters(in: .whitespaces) : ""
                            if v.hasSuffix("$") { strVars[v] = val }
                            else { numVars[v] = Double(val) ?? 0 }
                        }
                        execNext()
                    }
                case .getNeeded(let varName):
                    inputHandler?("") { [self] userInput in
                        let ch = userInput.first.map { String($0) } ?? ""
                        if varName.hasSuffix("$") { strVars[varName] = ch }
                        else { numVars[varName] = Double(ch) ?? 0 }
                        execNext()
                    }
                default:
                    running = false
                    completion(output)
                }
            } catch let e as BASICError {
                running = false
                output += e.message + "\n"
                completion(output)
            } catch {
                running = false
                completion(output)
            }
        }
        execNext()
    }
}
