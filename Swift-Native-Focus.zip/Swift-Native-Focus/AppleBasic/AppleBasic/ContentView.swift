import SwiftUI

// MARK: - Colors

private extension Color {
    static let terminalGreen = Color(red: 0.0, green: 0.85, blue: 0.15)
    static let terminalAmber = Color(red: 1.0, green: 0.75, blue: 0.0)
    static let terminalBackground = Color.black
    static let terminalDimGreen = Color(red: 0.0, green: 0.45, blue: 0.08)
}

// MARK: - Main ContentView

struct ContentView: View {
    @StateObject private var vm = TerminalViewModel()
    @FocusState private var inputFocused: Bool
    @State private var showColorPicker = false
    @State private var useAmber = false
    @State private var scanlineOpacity: Double = 0.04
    @State private var cursorVisible = true

    private let terminalFont = Font.custom("Menlo", size: 15).monospaced()
    private var phosphorColor: Color { useAmber ? .terminalAmber : .terminalGreen }

    var body: some View {
        ZStack {
            Color.terminalBackground.ignoresSafeArea()
            scanlines
            VStack(spacing: 0) {
                toolbar
                terminalOutput
                inputBar
            }
        }
        .statusBarHidden(true)
        .onAppear { inputFocused = true; startCursorBlink() }
    }

    // MARK: - Scanlines

    private var scanlines: some View {
        VStack(spacing: 3) {
            ForEach(0..<300, id: \.self) { _ in
                Color.black.frame(height: 1)
                Color.clear.frame(height: 2)
            }
        }
        .opacity(scanlineOpacity)
        .ignoresSafeArea()
        .allowsHitTesting(false)
    }

    // MARK: - Toolbar

    private var toolbar: some View {
        HStack(spacing: 16) {
            Text("APPLE BASIC")
                .font(.system(size: 11, weight: .bold, design: .monospaced))
                .foregroundColor(phosphorColor.opacity(0.6))
                .tracking(3)

            Spacer()

            if vm.isRunning {
                HStack(spacing: 6) {
                    Circle()
                        .fill(Color.red)
                        .frame(width: 7, height: 7)
                    Button("STOP") {
                        vm.stopProgram()
                    }
                    .font(.system(size: 11, weight: .bold, design: .monospaced))
                    .foregroundColor(.red)
                }
            }

            Button(action: { useAmber.toggle() }) {
                Image(systemName: "circle.lefthalf.filled")
                    .font(.system(size: 14))
                    .foregroundColor(phosphorColor.opacity(0.6))
            }
            .buttonStyle(.plain)

            Button(action: { vm.clearScreen() }) {
                Image(systemName: "clear")
                    .font(.system(size: 14))
                    .foregroundColor(phosphorColor.opacity(0.6))
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
        .background(
            Color.black
                .overlay(
                    Rectangle()
                        .frame(height: 1)
                        .foregroundColor(phosphorColor.opacity(0.2)),
                    alignment: .bottom
                )
        )
    }

    // MARK: - Terminal Output

    private var terminalOutput: some View {
        ScrollViewReader { proxy in
            ScrollView(.vertical, showsIndicators: false) {
                LazyVStack(alignment: .leading, spacing: 0) {
                    ForEach(vm.lines) { line in
                        TerminalLineView(
                            text: line.text,
                            isInput: line.isInput,
                            color: phosphorColor,
                            font: terminalFont
                        )
                        .id(line.id)
                    }

                    if vm.isWaitingForInput {
                        inputCursorLine
                            .id("inputCursor")
                    }
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
            }
            .onChange(of: vm.lines.count) { _ in
                withAnimation(.none) {
                    if let last = vm.lines.last {
                        proxy.scrollTo(last.id, anchor: .bottom)
                    }
                    if vm.isWaitingForInput {
                        proxy.scrollTo("inputCursor", anchor: .bottom)
                    }
                }
            }
            .onChange(of: vm.isWaitingForInput) { _ in
                withAnimation(.none) {
                    proxy.scrollTo("inputCursor", anchor: .bottom)
                }
            }
        }
    }

    private var inputCursorLine: some View {
        HStack(spacing: 0) {
            Text(vm.inputText)
                .font(terminalFont)
                .foregroundColor(phosphorColor)
            if cursorVisible {
                Rectangle()
                    .fill(phosphorColor)
                    .frame(width: 9, height: 16)
            }
            Spacer()
        }
    }

    // MARK: - Input Bar

    private var inputBar: some View {
        VStack(spacing: 0) {
            Rectangle()
                .fill(phosphorColor.opacity(0.2))
                .frame(height: 1)

            HStack(spacing: 0) {
                if !vm.isWaitingForInput {
                    Text("]")
                        .font(terminalFont)
                        .foregroundColor(phosphorColor)
                        .padding(.leading, 12)
                }

                TextField("", text: $vm.inputText)
                    .font(terminalFont)
                    .foregroundColor(phosphorColor)
                    .tint(phosphorColor)
                    .keyboardType(.asciiCapable)
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.characters)
                    .focused($inputFocused)
                    .submitLabel(.return)
                    .onSubmit { handleSubmit() }
                    .padding(.horizontal, 8)
                    .padding(.vertical, 10)

                if !vm.inputText.isEmpty {
                    Button(action: handleSubmit) {
                        Image(systemName: "return")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundColor(phosphorColor)
                            .padding(.horizontal, 12)
                    }
                    .buttonStyle(.plain)
                }
            }
            .background(Color.black)
        }
        .safeAreaInset(edge: .bottom) { Color.clear.frame(height: 0) }
    }

    // MARK: - Actions

    private func handleSubmit() {
        let text = vm.inputText
        guard !text.isEmpty else { return }
        if vm.isWaitingForInput {
            vm.submitInput(text)
            vm.inputText = ""
        } else {
            vm.executeCommand(text)
        }
    }

    private func startCursorBlink() {
        Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { _ in
            Task { @MainActor in
                self.cursorVisible.toggle()
            }
        }
    }
}

// MARK: - Terminal Line View

struct TerminalLineView: View {
    let text: String
    let isInput: Bool
    let color: Color
    let font: Font

    var body: some View {
        Text(text.isEmpty ? " " : text)
            .font(font)
            .foregroundColor(isInput ? color.opacity(0.7) : color)
            .shadow(color: color.opacity(0.6), radius: 3)
            .frame(maxWidth: .infinity, alignment: .leading)
            .lineLimit(nil)
            .fixedSize(horizontal: false, vertical: true)
    }
}

// MARK: - Preview

#Preview {
    ContentView()
        .preferredColorScheme(.dark)
}
