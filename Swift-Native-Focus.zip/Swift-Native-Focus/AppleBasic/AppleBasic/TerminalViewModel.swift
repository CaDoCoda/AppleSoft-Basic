import Foundation
import SwiftUI

struct TerminalLine: Identifiable {
    let id = UUID()
    var text: String
    var isInput: Bool = false
}

@MainActor
class TerminalViewModel: ObservableObject {
    @Published var lines: [TerminalLine] = []
    @Published var inputText: String = ""
    @Published var isWaitingForInput: Bool = false
    @Published var inputPrompt: String = ""
    @Published var isRunning: Bool = false

    private let interpreter = BASICInterpreter()
    private var inputCompletion: ((String) -> Void)?
    private var inputVars: [String] = []

    init() {
        setupInterpreter()
        showWelcome()
    }

    private func setupInterpreter() {
        interpreter.outputHandler = { [weak self] text in
            Task { @MainActor in
                self?.appendOutput(text)
            }
        }
        interpreter.inputHandler = { [weak self] prompt, completion in
            Task { @MainActor in
                self?.requestInput(prompt: prompt, completion: completion)
            }
        }
    }

    private func showWelcome() {
        let welcome = """

        ]APPLE II BASIC
        ]APPLESOFT BASIC INTERPRETER v1.1
        ]COPYRIGHT 1976 APPLE COMPUTER INC.
        ]
        ]
        """
        for line in welcome.split(separator: "\n", omittingEmptySubsequences: false) {
            lines.append(TerminalLine(text: String(line)))
        }
    }

    func submitInput(_ text: String) {
        guard isWaitingForInput else { return }
        isWaitingForInput = false
        let prompt = inputPrompt
        appendOutput(text + "\n")
        let completion = inputCompletion
        inputCompletion = nil
        inputPrompt = ""
        completion?(text)
    }

    func executeCommand(_ command: String) {
        guard !isWaitingForInput && !isRunning else { return }
        let display = "]\(command)"
        lines.append(TerminalLine(text: display, isInput: true))
        inputText = ""

        if command.trimmingCharacters(in: .whitespaces).uppercased() == "RUN" ||
           command.trimmingCharacters(in: .whitespaces).uppercased().hasPrefix("RUN ") {
            isRunning = true
            interpreter.executeDirectCommand(command) { [weak self] output in
                Task { @MainActor in
                    self?.isRunning = false
                    if !output.isEmpty {
                        self?.appendOutput(output)
                    }
                    self?.appendPrompt()
                }
            }
        } else if command.trimmingCharacters(in: .whitespaces).uppercased() == "NEW" {
            interpreter.executeDirectCommand(command) { [weak self] _ in
                Task { @MainActor in
                    self?.appendOutput("\n")
                    self?.appendPrompt()
                }
            }
        } else {
            interpreter.executeDirectCommand(command) { [weak self] output in
                Task { @MainActor in
                    self?.isRunning = false
                    if !output.isEmpty {
                        self?.appendOutput(output)
                    }
                    self?.appendPrompt()
                }
            }
        }
    }

    func stopProgram() {
        interpreter.stop()
        isRunning = false
        isWaitingForInput = false
        inputCompletion = nil
    }

    private func requestInput(prompt: String, completion: @escaping (String) -> Void) {
        inputPrompt = prompt
        inputCompletion = completion
        if !prompt.isEmpty {
            appendOutput(prompt)
        }
        isWaitingForInput = true
    }

    private func appendOutput(_ text: String) {
        guard !text.isEmpty else { return }
        let parts = text.components(separatedBy: "\n")
        for (i, part) in parts.enumerated() {
            if i == 0 {
                if let last = lines.last {
                    lines[lines.count - 1] = TerminalLine(text: last.text + part, isInput: last.isInput)
                } else {
                    lines.append(TerminalLine(text: part))
                }
            } else {
                lines.append(TerminalLine(text: part))
            }
        }
        if lines.count > 1000 {
            lines.removeFirst(lines.count - 1000)
        }
    }

    private func appendPrompt() {
        appendOutput("]")
    }

    func clearScreen() {
        lines = []
        appendPrompt()
    }
}
